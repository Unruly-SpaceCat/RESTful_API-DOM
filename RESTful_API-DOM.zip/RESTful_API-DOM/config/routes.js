var controller = require('../controllers/controller');

module.exports = function(app) {
    app.get('/tasks', controller.home_function);
    app.get('/tasks/:id', controller.get_one);
    app.post('/tasks', controller.create_one);
    app.put('/tasks/:id', controller.update_one);
    app.delete('/tasks/:id', controller.delete_one);
}