var Task = require('../models/task');

// Export functions for our routes.js file to use. This is where the logic of
// your server will go.
module.exports = {

    home_function: function(req, res){
        console.log("get all")
        tasks = Task.find()
        .then(tasks=>  {
            var response = {}
            response['message'] = "Success"
            response['tasks'] = tasks
            res.json(response)
        })
        .catch(err => res.json(err))
    },
    get_one: function(req, res){
        const { id } = req.params
        Task.findOne({_id: id })
        .then(task => res.json(task))
        .catch(err => res.json(err))
    },
    create_one: function(req, res){
        const newtask = new Task()
        newtask.title = req.body.title
        newtask.description = req.body.description
        newtask.completed = req.body.completed
        newtask.save()
        .then(newTask => {
            console.log("new tasked saved", newTask)
            res.redirect('/tasks')
        })
        .catch(err => {
            console.log(err)
            res.redirect('/tasks')
        })
    },
    update_one: function(req, res){
        const { id } = req.params
        Task.findOne({_id: id })
        .then(task => {
            if(req.body.title.length > 0){
                task.title = req.body.title
            }
            if(req.body.description.length > 0){
                task.description = req.body.description
            }
            if(req.body.completed !== task.completed){
                task.completed = req.body.completed
            }
            task.save()          
        })
        .catch(err => res.json(err))
        .then(updatedtask => {
            console.log("updated task", updatedtask)
            res.redirect('/tasks')
        })    
    },
    delete_one: function(req, res){
        const { id } = req.params
        Task.remove({_id: id })
        .then(deletedtask => {
            console.log(deletedtask)
            res.redirect('/tasks')
        })
         .catch(err => {
             console.log(err)
             res.redirect('/tasks')
        })
    }
}